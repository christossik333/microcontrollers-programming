/// @file bitswap.cpp
/// Functions for doing a rotation of bits/bytes used by parallel output

/// Disables pragma messages and warnings
#define FASTLED_INTERNAL

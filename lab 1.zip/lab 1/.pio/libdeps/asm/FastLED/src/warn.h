#pragma once

#ifndef FASTLED_WARN
// in the future this will do something
#define FASTLED_WARN(MSG)
#endif
